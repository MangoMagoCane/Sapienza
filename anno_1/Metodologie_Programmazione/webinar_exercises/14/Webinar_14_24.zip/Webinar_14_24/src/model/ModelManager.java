package model;

import java.util.Observable;

public class ModelManager extends Observable {
	
	private static ModelManager instance;
	
	private Counter counter;
	
	private ModelManager()
	{
		this.counter=new Counter();
	}
	
	public static ModelManager getInstance()
	{
		if (instance==null) instance=new ModelManager();
		return instance;
	}
	
	public void incCounter()
	{
		counter.incValue();
		setChanged();
		notifyObservers(counter.toString());
	}
	public void decCounter()
	{
		counter.decValue();
		setChanged();
		notifyObservers(counter.toString());
	}	
	public void resetCounter(int value)
	{
		counter.reset(value);
		setChanged();
		notifyObservers(counter.toString());
	}
	public void updateModel() 
	{
		incCounter();
		System.out.println(counter);
	}
	@Override
	public String toString()
	{
		return counter.getValue()+"" ;
	}
}
