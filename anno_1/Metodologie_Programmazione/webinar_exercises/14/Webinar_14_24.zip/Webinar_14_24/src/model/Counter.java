package model;

public class Counter {

	private int value; 
	
	
	public Counter()
	{

	}
	/**
	 * 
	 * @param initValue
	 */
	public Counter(int initValue)
	{
		reset(initValue);
	}
	
	public int getValue()
	{
		return value;
	}
	
	public void incValue()
	{
		value++;
	}
	
	public void decValue()
	{
		value--;	
	}
	public void reset(int resetValue)
	{
		value=resetValue;
	}
	@Override
	public String toString()
	{
		return "Counter.value: "+value;
	}
}
