package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.ModelManager;

public class ResetActionListener implements ActionListener{

	
	public void actionPerformed(ActionEvent e) {
	
		ModelManager.getInstance().resetCounter(0);
	}

}
