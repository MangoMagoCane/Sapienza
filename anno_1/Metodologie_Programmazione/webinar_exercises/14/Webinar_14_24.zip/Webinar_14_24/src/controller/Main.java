package controller;

import model.ModelManager;
import view.CounterView;
import java.awt.event.ActionListener;

public class Main {

	public static void main(String[] args) {
		
		// crea il modello
		ModelManager mm=ModelManager.getInstance();
		// crea la view
		CounterView cv=new CounterView();
		cv.setVisible(true);
		// innesca il meccanismo Observer-Observable
		mm.addObserver(cv);
		//aggancia gli ActionListener
		ActionListener ral=new ResetActionListener();
		cv.addResetButtonListener(ral);
		
		// gameloop
		while (true)
		{
			try {
				Thread.sleep(1000/60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			mm.updateModel();
		}
	}

}
