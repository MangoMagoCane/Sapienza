import controller.Main;

public class JCounter {

	public static void main(String[] args) {
		Main.main(args);
	}

}
