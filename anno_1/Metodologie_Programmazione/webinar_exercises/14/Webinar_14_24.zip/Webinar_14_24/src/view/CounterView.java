package view;

import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;

public class CounterView extends JFrame implements Observer{

	public static final String TITLE="JCounter ver. 1.0";
	private CounterPanel cp;
	private JButton b;
	public CounterView()
	{
		super(TITLE);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(new Rectangle(50,50,850,650));
		cp=new CounterPanel();
		add(cp,BorderLayout.CENTER);
		b=new JButton("RESET");
		add(b,BorderLayout.SOUTH);
	}
	public void addResetButtonListener(ActionListener al)
	{
		b.addActionListener(al);
	}
	
	@Override
	public void update(Observable o, Object arg) {
		//non è bloccante
		cp.repaint();
		System.out.println("View received:"+arg);
	}

}
