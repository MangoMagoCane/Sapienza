package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import model.ModelManager;

public class CounterPanel extends JPanel {

	public CounterPanel()
	{
		this.setBackground(Color.WHITE);
	}
	
	/**
	 * 
	 */
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D g2=(Graphics2D)g;
				
		this.setForeground(Color.BLACK);
		g2.drawString(ModelManager.getInstance().toString(), 20, 40);
		
	}
	
}
